#ifndef funcs_h
#define funcs_h

void _sortirovka(double* mass, int n);
void _vivod(double* mass, int n);

#endif
