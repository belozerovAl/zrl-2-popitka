#ifndef hex_h
#define hex_h
#include <stdio.h>
void hex(char* line1, char* line2, char sim);
void hex_1(char* line1);
#endif
